You can carry out this exercise in your own time, in your IDE of choice.

This project will give you a chance to demonstrate your skills in a variety of different methodologies.
Some of the things we think are important:

* Clean Code
* Unit Tests/Test-driven Development (TDD)
* Design patterns
* Refactoring