package com.ncr.chess;

public class ChessBoard {

    public static int MAX_BOARD_WIDTH = 7;
    public static int MAX_BOARD_HEIGHT = 7;

    private PieceColor turn;

    private Pawn[][] pieces;

    public ChessBoard() {
        pieces = new Pawn[MAX_BOARD_WIDTH][MAX_BOARD_HEIGHT];
    }

    public ChessBoard(boolean initPieces) {
        turn = PieceColor.WHITE;

        if (initPieces) {
            // black pieces
            pieces[0][1] = new Pawn(PieceColor.BLACK);
            pieces[1][1] = new Pawn(PieceColor.BLACK);
            pieces[2][1] = new Pawn(PieceColor.BLACK);
            pieces[3][1] = new Pawn(PieceColor.BLACK);
            pieces[4][1] = new Pawn(PieceColor.BLACK);
            pieces[5][1] = new Pawn(PieceColor.BLACK);
            pieces[6][1] = new Pawn(PieceColor.BLACK);
            pieces[7][1] = new Pawn(PieceColor.BLACK);

            // white pieces
            pieces[0][6] = new Pawn(PieceColor.BLACK);
            pieces[1][6] = new Pawn(PieceColor.BLACK);
            pieces[2][6] = new Pawn(PieceColor.BLACK);
            pieces[3][6] = new Pawn(PieceColor.BLACK);
            pieces[4][6] = new Pawn(PieceColor.BLACK);
            pieces[5][6] = new Pawn(PieceColor.BLACK);
            pieces[6][6] = new Pawn(PieceColor.BLACK);
            pieces[7][6] = new Pawn(PieceColor.BLACK);

        }
    }

    public void addPiece(Pawn pawn, int xCoordinate, int yCoordinate, PieceColor pieceColor) {
        if (isLegalBoardPosition(xCoordinate, yCoordinate)) {
            if (pieces[xCoordinate][yCoordinate] == null) {
                pawn.setXCoordinate(xCoordinate);
                pawn.setYCoordinate(yCoordinate);
                pieces[xCoordinate][yCoordinate] = pawn;
            } else {
                pawn.setXCoordinate(-1);
                pawn.setYCoordinate(-1);
            }
        } else {
            pawn.setXCoordinate(-1);
            pawn.setYCoordinate(-1);
        }
    }

    public Pawn getPiece(int xCoordinate, int yCoordinate) {
        return pieces[xCoordinate][yCoordinate];
    }


    public boolean isLegalBoardPosition(int xCoordinate, int yCoordinate) {
        if (xCoordinate >= 0 && xCoordinate <= 7 && yCoordinate >= 0 && yCoordinate <= 7) {
            return true;
        }
        return false;
    }
}
