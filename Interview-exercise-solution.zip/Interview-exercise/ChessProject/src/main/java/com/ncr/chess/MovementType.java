package com.ncr.chess;

public enum MovementType {

    MOVE, CAPTURE
}
