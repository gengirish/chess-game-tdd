package com.ncr.chess;

public enum PieceColor {

    BLACK, WHITE

}
